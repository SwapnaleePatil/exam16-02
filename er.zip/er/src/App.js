import React, { Component } from 'react';

import './App.css';
import TableDisp from "./modal/tabledisp";

class App extends Component {
  render() {
    return (
      <div className="App">

        <TableDisp/>
      </div>
    );
  }
}

export default App;
