import React from 'react';
import {Table, Button, Label, Form, Glyphicon, Alert, Modal} from 'react-bootstrap';
const _=require('lodash');
const axios = require('axios');
var uid = '';

class TableDisp extends React.Component {
    constructor() {
        super()
        this.state = {
            detailData: [],
            cityArr: [],
            curCityArr: [],
            stateArr: [],
            currentData: [],
            isEditing: false,
            isActive: false,
            isDactive: false,
            stateindex: '',
            selectedstate: '',
            selectedstateid: '',
            hobbiesArr: [],
            photo: '',
            previewFile: '',

            //page
            cuurentpage1:1,
            currentRec:3,
            isAsc:false,
            //Searching
            isSearch:false,
            searchArr:[]

        }
        this.getData = this.getData.bind(this);
        this.getCity = this.getCity.bind(this);
        this.getState = this.getState.bind(this);
        this.toggleActive = this.toggleActive.bind(this);
        this.dtoggleActive = this.dtoggleActive.bind(this);
        this.submitStud = this.submitStud.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.uploadFile = this.uploadFile.bind(this);
        this.handleHobbies = this.handleHobbies.bind(this);
        this.clearData = this.clearData.bind(this);
        this.deleteData = this.deleteData.bind(this);
        this.updateData = this.updateData.bind(this);
        this.handleDrop=this.handleDrop.bind(this);
        this.sortA=this.sortA.bind(this);
        this.myPage=this.myPage.bind(this);
        this.handleName=this.handleName.bind(this);
    }

    toggleActive() {
        this.setState({
            isActive: !this.state.isActive,
            isEditing: false
        })
        this.clearData();
    }
    dtoggleActive(d) {
        // console.
        debugger;
        this.setState({
            isDactive: !this.state.isDactive,
            deleteId: d && d._id
            // isEditing: false
        })
    }
    sortA(e){


    let{detailData} = this.state;
    if(this.state.isAsc) {
        detailData = _.orderBy(detailData, ['name'], ['asc']);
        console.log('asc sorted array:',detailData);
    }
    else {
        detailData = _.orderBy(detailData, ['name'], ['desc']);
        console.log('desc sorted array:',detailData);
    }
    this.setState({
        isAsc:!this.state.isAsc,
        detailData
    })
}

    componentWillMount() {
        this.getData();
        this.getCity();
        this.getState();
    }

    handleDrop(e){
        this.setState({
            currentRec:e.target.value
        })
    }
    myPage(no){
        this.setState({
            cuurentpage1:no
        })
    }
    clearData() {

        this.state.currentData.name = '';
        this.state.currentData.age = '';
        this.state.currentData.email = '';
        this.state.currentData.contact = '';
        this.state.currentData.password = '';
        this.state.pic='';
        this.state.previewFile='';


        console.log("Curren", this.state.currentData);
    }
    handleName(event){
        this.setState({
            isSearch:true,
            searchArr:[]
        })
        let {searchArr}=this.state
        searchArr=[];
        this.state.detailData.map((values,index)=>{
            if(values.name.includes(event.target.value))
            {
                searchArr.push(values);
            }

            else if (values.email.includes(event.target.value))
            {
                searchArr.push(values);
            }

            if(event.target.value==="")
            {
                this.setState({
                    isSearch:false
                });
            }

        })
        this.setState({
            searchArr
        })
    }
    deleteData(sid) {
        // alert(sid);
        axios.post("http://localhost:5151/deleteData", {
            id: sid
        }).then((success) => {
            // alert('success');
            console.log("Success", success.data);
            //this.getData();

            var dt=this.state.detailData.filter((d)=>success.data['_id']!==d._id);
            let data=this.state.detailData;
            data.splice(data.find((e)=>{ return e._id===sid}),1);

            //this.dtoggleActive();
            console.log("dt".this.state.detailData);
            this.setState({
                isDactive: false,
                detailData:data,
                // isEditing: false
            })
        }).catch((e) => {
            console.log("Error", e)
        })
    }
    handleHobbies(event) {
        let {hobbiesArr} = this.state;
        hobbiesArr.push(event.target.value + '||');
        this.setState({hobbiesArr}, () => {
            console.log("Hobbie", hobbiesArr);
        })
    }
    handleChange(event) {
        const {value, name} = event.target
        const currentData = this.state.currentData;
        currentData[name] = value;
        this.setState({currentData}, () => {
            console.log("CurrentData", this.state.currentData);
        })
    }
    submitStud(e) {
        e.preventDefault();

        // alert(this.state.currentData);
        axios.post("http://localhost:5151/addData", {

            pic: this.state.previewFile,
            hobbies: this.state.hobbiesArr,
            ...this.state.currentData
        }).then((success) => {
            (!success)
            {
                console.log("Data not Found");
            }
            let {detailData} = this.state;
            detailData[0].push(success.data);
            this.setState({detailData})
            this.clearData();
            this.toggleActive();
        }).catch((e) => {
            console.log("Error", e);
        })
        this.clearData();
    }
    updateData(e) {
        e.preventDefault();
        axios.post("http://localhost:5151/editData", {
            id:uid,
            pic: this.state.photo,
            hobbies: this.state.hobbiesArr,
            ...this.state.currentData
        }).then((success) => {

            (!success)
            {
                console.log("Data not Found");
            }
            this.setState({
                detailData: this.state.detailData
            })
            console.log("DetailData", this.state.detailData);

            this.clearData();
            this.toggleActive();
        }).catch((e) => {
            console.log("Error", e);
        })
        this.clearData();
    }
    uploadFile = (e) => {
  console.log("startimage:",this.state.previewFile)
        // alert("Upload File")
        e.preventDefault();
        let{currentData} = this.state;

        let reader = new FileReader();
        let file = e.target.files[0];
        //console.log('file',file);
        reader.onloadend = () => {
            currentData.pic = reader.result;
            this.setState({
                photo: file,
                previewFile: reader.result,
                currentData

            });
            console.log("endimage",this.state.previewFile)
        };
        reader.readAsDataURL(file);
        console.log("File Upload",this.state.previewFile);
    }
    reverse=()=>{
        let {detailData}=this.state;
        detailData.reverse();
        this.setState({detailData});
    };
    getData() {
        // alert('getdata');
        axios.get('http://localhost:5151/fetchstud')
            .then((success) => {
                if (!success) {
                    console.log("Not Found");
                }
                this.setState({
                    detailData: success.data
                })

                console.log("Data", this.state.detailData);
            })
            .catch((e) => {
                console.log("error", e)
            })

    }
    getCity() {
        axios.get('http://localhost:5151/fetchcity')
            .then((success) => {
                if (!success) {
                    console.log("Not Found");
                }
                this.setState({
                    cityArr: success.data
                })
                console.log("Data", this.state.cityArr);
            })
            .catch((e) => {
                console.log("error", e)
            })

    }
    getCityByState() {
        // alert();

        this.state.curCityArr = [];
        const state = this.state.currentData.state;
        this.state.stateArr.map((s, i) => {
            //console.log(s._id);
            if (s._id === state) {
                console.log("State Id", s._id);
                console.log("State Id", s.statename);
                this.setState({
                    selectedstate: s.statename,
                    selectedstateid: s._id
                }, () => {
                    this.state.cityArr.map((c, i) => {
                        //  console.log("c",c.stateid);
                        //   console.log("csds",this.state.selectedstateid);
                        if (c.stateid === this.state.selectedstateid) {
                            // console.log("c",c);
                            let {curCityArr} = this.state;
                            curCityArr.push(c);
                            this.setState({curCityArr});

                        }
                    })
                });
            }
        })


    }
    getState() {
        axios.get('http://localhost:5151/fetchstate')
            .then((success) => {
                if (!success) {
                    console.log("Not Found");
                }
                this.setState({
                    stateArr: success.data
                })
                console.log("Data", this.state.stateArr);
            })
            .catch((e) => {
                console.log("error", e)
            })

    }
    render() {
        var len=this.state.detailData.length;
        var totalPages=Math.ceil(len/this.state.currentRec);
        var pages=[];
        var isSearch=this.state.isSearch;
        for(let i=1;i<=totalPages;i++)
        {
            pages.push(i);
        }
        var last=this.state.currentRec*this.state.cuurentpage1;
        var first=last-this.state.currentRec
        var totrec=this.state.detailData.slice(first,last);
        const currentData = this.state.currentData;
        const isEditing = this.state.isEditing;
        return (
            <div>
                <div>
                    <Button bsStyle="primary" bsSize="large" active onClick={this.toggleActive}>Insert New
                        Record</Button>
                    <Modal show={this.state.isActive} onHide={this.toggleActive}>
                        <Modal.Header closeButton>
                            <Modal.Title>Student Details</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form method="post" action="#" >
                                <Table striped bordered condensed hover>
                                    <tr>
                                        <td>Student Name:</td>
                                        <td><input className="form-control" value={currentData.name} type="text"
                                                   name="name" id="name" onChange={this.handleChange} required={true}/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Age:</td>
                                        <td><input className="form-control" value={currentData.age} type="text"
                                                   name="age" onChange={this.handleChange}/></td>
                                    </tr>
                                    <tr>
                                        <td>Contact:</td>
                                        <td><input className="form-control" value={currentData.contact} type="text"
                                                   name="contact" onChange={this.handleChange}/></td>
                                    </tr>
                                    <tr>
                                        <td>Gender:</td>


                                        <div>
                                            <label className="radio-inline"><input type="radio" name="gender"
                                                                                   checked={currentData.gender === "female" ? true : false}
                                                                                   value="female"
                                                                                   onChange={this.handleChange}/>Female</label>
                                            <label className="radio-inline"><input type="radio" name="gender"
                                                                                   checked={currentData.gender === "male" ? true : false}
                                                                                   value="male"
                                                                                   onChange={this.handleChange}/>Male</label>
                                        </div>

                                    </tr>
                                    <tr>
                                        <td>Email:</td>
                                        <td><input className="form-control" type="email" value={currentData.email}
                                                   name="email" onChange={this.handleChange}/></td>
                                    </tr>
                                    <tr>
                                        <td>Password:</td>
                                        <td><input className="form-control" type="password" name="password"
                                                   value={currentData.password} onChange={this.handleChange}/></td>
                                    </tr>
                                    <tr>
                                        <td>Hobbies:</td>
                                        <div>
                                            <label className="form-check-label">
                                                <input type="checkbox" name="reading" className="form-check-input"
                                                       onChange={this.handleHobbies} value="reading"/>Reading
                                            </label>
                                        </div>
                                        <div>
                                            <label className="form-check-label">
                                                <input type="checkbox" name="writing" className="form-check-input"
                                                       onChange={this.handleHobbies} value="writing"/>Writing
                                            </label>
                                        </div>
                                        <div>
                                            <label className="form-check-label">
                                                <input type="checkbox" name="singing" className="form-check-input"
                                                       onChange={this.handleHobbies} value="singing"/>Singing
                                            </label>
                                        </div>
                                        <div>
                                            <label className="form-check-label">
                                                <input type="checkbox" name="dancing" className="form-check-input"
                                                       onChange={this.handleHobbies} value="dancing"/>Dancing
                                            </label>
                                        </div>


                                    </tr>
                                    <tr>
                                        <td>State:</td>
                                        <td><select className="form-control" id="state" name="state" onChange={(e) => {
                                            this.handleChange(e)
                                            this.getCityByState(e)
                                        }}>

                                            {isEditing ? <option defaultValue={currentData.state}>{
                                                    this.state.stateArr.map((st, i) => {
                                                        if (currentData.state === st._id) {
                                                            return st.statename;
                                                        }
                                                    })
                                                }</option>
                                                : <option>--Select State--</option>}

                                            <option>--Select State--</option>
                                            {
                                                this.state.stateArr.map((s, i) => {
                                                    return <option value={s._id}>{s.statename}</option>
                                                })
                                            }
                                        </select></td>
                                    </tr>
                                    <tr>
                                        <td>City:</td>
                                        <td><select className="form-control" id="city" name="city"
                                                    onChange={this.handleChange}>
                                            {isEditing ? <option defaultValue={currentData.city}>{
                                                    this.state.cityArr.map((ct, i) => {
                                                        if (currentData.city === ct._id) {
                                                            return ct.cityname;
                                                        }
                                                    })
                                                }</option>
                                                : <option>--Select State--</option>}
                                            <option>--Select State--</option>
                                            {
                                                this.state.curCityArr.map((c, i) => {

                                                    return <option value={c._id}>{c.cityname}</option>
                                                })
                                            }
                                        </select></td>
                                    </tr>
                                    <tr>
                                        <td>Image:</td>
                                        <td><input className="form-control" type="file" name="filen"
                                                   onChange={this.uploadFile}/>
                                             <img src={this.state.previewFile} alt="" height="25%" width="25%"/>


                                        </td>
                                    </tr>

                                </Table>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            {isEditing ?
                                <Button type="submit" active className="btn btn-default" onClick={(e) => {
                                    this.updateData(e)
                                }}>Update</Button>

                                :
                                <Button type="submit" active className="btn btn-default" onClick={(e)=>{
                                this.submitStud(e)}
                                }
                                >Submit</Button>

                            }
                            <Button type="button" active className="btn btn-default"
                                    onClick={this.toggleActive}>Close</Button>


                        </Modal.Footer>
                    </Modal>
                    <div>
                        <select onChange={this.handleDrop}>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>

                        Search :
                        <input type="text" name="txtn" id="txtn" onChange={this.handleName}/>
                    </div>
                    <div>
                        <Table striped bordered condensed hover>
                            <thead>
                            <tr>
                                <th value={this.state.isAsc} onDoubleClick={(e)=>{
                                    this.sortA(e)
                                }}>Student Name</th>
                                <th>Age</th>
                                <th>Contact</th>
                                <th>Gender</th>
                                <th>Email</th>
                                <th>Hobbies</th>
                                <th>State</th>
                                <th>City</th>
                                <th>Image</th>
                                <th colSpan="2">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            {
                                isSearch ? this.state.searchArr.map((d, i) => {
                                    console.log("DetailData", this.state.detailData)
                                    return <tr>

                                        <td>{d.name}</td>
                                        <td>{d.age}</td>
                                        <td>{d.contact}</td>
                                        <td>{d.gender}</td>
                                        <td>{d.email}</td>
                                        <td>{d.hobbies}</td>
                                        <td>
                                            {
                                                this.state.stateArr.map((st, i) => {
                                                    if (d.state === st._id) {
                                                        return st.statename;
                                                    }
                                                })
                                            }
                                        </td>
                                        <td> {
                                            this.state.cityArr.map((ct, i) => {
                                                if (d.city === ct._id) {
                                                    return ct.cityname;
                                                }
                                            })
                                        }</td>
                                        <td><img src={d.pic} height="50px" width="50px"/></td>
                                        <td><Glyphicon glyph="glyphicon glyphicon-pencil"
                                                       onClick={() => {
                                                           uid = d._id;
                                                           this.setState({
                                                               isEditing: true,
                                                               isActive: true,
                                                               currentData: d
                                                           })
                                                       }}/>


                                        </td>
                                        <th>
                                            <Glyphicon glyph="glyphicon glyphicon-remove"
                                                       onClick={this.dtoggleActive}/>

                                            <Modal show={this.state.isDactive} onHide={this.toggleActive}>
                                                <Modal.Header closeButton>
                                                    <Modal.Title>Student Details</Modal.Title>
                                                </Modal.Header>
                                                <Modal.Body>
                                                    Are you sure, you want to delete
                                                </Modal.Body>
                                                <Modal.Footer>
                                                    <Button bsStyle="danger" active="true" onClick={() => {
                                                        uid = d._id
                                                        console.log("uid", uid);
                                                        this.deleteData(d._id);
                                                    }}>Delete
                                                    </Button>
                                                    <Button bsStyle="danger" active
                                                            onClick={this.dtoggleActive}>Cancel</Button>
                                                </Modal.Footer>

                                            </Modal>

                                        </th>
                                    </tr>
                                }) :
                                    totrec.map((d, i) => {

                                    console.log("DetailData", this.state.detailData)
                                    return <tr>

                                        <td>{d.name}</td>
                                        <td>{d.age}</td>
                                        <td>{d.contact}</td>
                                        <td>{d.gender}</td>
                                        <td>{d.email}</td>
                                        <td>{d.hobbies}</td>
                                        <td>
                                            {
                                                this.state.stateArr.map((st, i) => {
                                                    if (d.state === st._id) {
                                                        return st.statename;
                                                    }
                                                })
                                            }
                                        </td>
                                        <td> {
                                            this.state.cityArr.map((ct, i) => {
                                                if (d.city === ct._id) {
                                                    return ct.cityname;
                                                }
                                            })
                                        }</td>
                                        <td><img src={d.pic} height="50px" width="50px"/></td>
                                        <td><Glyphicon glyph="glyphicon glyphicon-pencil"
                                                       onClick={() => {
                                                           uid = d._id;
                                                           this.setState({
                                                               isEditing: true,
                                                               isActive: true,
                                                               currentData: d,
                                                               previewFile:d.pic

                                                           })
                                                       }}/>


                                        </td>
                                        <th>
                                            {/*<div onClick={() => this.dtoggleActive(d)}>*/}
                                                {/*X*/}
                                            {/*</div>*/}
                                            <Glyphicon glyph="glyphicon glyphicon-remove"
                                                       onClick={() => this.dtoggleActive(d)}/>

                                        </th>
                                    </tr>
                                })

                            }
                            <Modal show={this.state.isDactive} onHide={this.toggleActive}>
                                <Modal.Header closeButton>
                                    <Modal.Title>Student Details</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>
                                    Are you sure, you want to delete
                                </Modal.Body>
                                <Modal.Footer>
                                    <button bsStyle="danger" active onClick={() => {
                                        console.log(this.state);
                                        debugger;
                                        this.deleteData(this.state.deleteId);
                                        this.dtoggleActive()
                                    }}>Delete
                                    </button>
                                    <Button bsStyle="danger" active
                                            onClick={this.dtoggleActive}>Cancel</Button>
                                </Modal.Footer>

                            </Modal>
                            </tbody>
                            <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Age</th>
                                <th>Contact</th>
                                <th>Gender</th>
                                <th>Email</th>
                                <th>Hobbies</th>
                                <th>State</th>
                                <th>City</th>
                                <th>Image</th>
                                <th colSpan="2">Action</th>
                            </tr>

                            </thead>
                            <thead>
                            <tr>
                                <td colSpan="11">
                            {
                                pages.map((a,i)=>{
                                    return <Button active onClick={()=>{
                                        this.myPage(a);
                                    }}>{a}</Button>
                                })
                            }
                                </td>
                            </tr>
                            </thead>
                        </Table>
                    </div>
                </div>
            </div>

        )
    }
}

export default TableDisp;