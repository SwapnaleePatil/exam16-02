const expree = require("express");
var app = expree();
const {stud} = require('./modal/stud');
const {state1} = require('./modal/state');
const {city} = require('./modal/city');
const bodyParser = require('body-parser');
const _ = require('lodash');

app.use(bodyParser.json());
app.use((req, res, next) => {

    res.header('Access-Control-Allow-Origin','*');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,x-auth");
    res.header("Access-Control-Allow-Credentials",true);
    res.header(`Access-Control-Allow-Methods`, `POST`);
    res.header(`Access-Control-Allow-Methods`, `DELETE`);
    res.header(`Access-Control-Allow-Methods`, `PATCH`);
    res.header(`Access-Control-Expose-Headers`, `x-auth`);
    next();
});
app.get('/', (req, res) => {
    res.send("Hello");
})
//Stud
app.post('/addData', (req, res) => {
    console.log("Hello");
    console.log("Body", req.body);
    let body = _.pick(req.body, ['name', 'age', 'contact', 'gender', 'email', 'password', 'hobbies', 'state', 'city', 'pic']);
    var newStud = new stud(body);

    newStud.save().then((stud) => {
        if (!stud) {
            console.log("Stud Not Found")
        }
        res.send(stud);
    }).catch((e) => {
        console.log(`Error is `,e)
    })

})
app.post('/editData', (req, res) => {
   // let body = _.pick(req.body, ['id','name', 'age', 'contact', 'gender', 'email', 'password', 'hobbies', 'state', 'city', 'pic']);
    let id = req.body.id;
    console.log(req.body);
    stud.findByIdAndUpdate(id, {$set: req.body}).then((stud) => {
        (!stud)
        {
            console.log("Stud Not Found");
        }
        res.send(stud);
        console.log("Student", stud)
    }).catch((e) => {
        console.log("Error", e);
    })

});
app.post('/deleteData', (req, res) => {
    let id=req.body.id;
    stud.findByIdAndUpdate(id,{$set:{flag:false}}).then((stud)=>{
        (!stud)
        {
            console.log("Stud Not Found");
        }
        res.send(stud);
    }).catch((e)=>{
        console.log("Error",e);
    })

})
app.get('/fetchstud',(req,res)=>{
    stud.find({flag:'true'}).then((stud)=>{
        (!stud)
        {
            console.log("Stud Not Found")
        }
        res.send(stud);
        })
        .catch((e)=>{
        console.log("Error",e);
        })
})

//state
app.post('/addstate', (req, res) => {
    console.log("Hello");
    console.log("Body", req.body);
    let body = _.pick(req.body, ['statename']);
    var newstate = new state1(body);

    newstate.save().then((state) => {
        if (!state) {
            console.log("Stud Not Found")
        }
        res.send(state);
    }).catch((e) => {
        console.log(`Error is {e}`)
    })

})
app.get('/fetchstate',(req,res)=>{
    state1.find({}).then((state)=>{
        (!state)
        {
            console.log("state Not Found")
        }
        res.send(state);
    })
        .catch((e)=>{
            console.log("Error",e);
        })
})

//city
app.post('/addcity', (req, res) => {
    console.log("Hello");
    console.log("Body", req.body);
    let body = _.pick(req.body, ['cityname', 'stateid']);
    var newcity = new city(body);

    newcity.save().then((city) => {
        if (!city) {
            console.log("city Not Found")
        }
        res.send(city);
    }).catch((e) => {
        console.log(`Error is {e}`)
    })

})
app.get('/fetchcity',(req,res)=>{
    city.find({}).then((city)=>{
        (city)
        {
            console.log("city Not Found")
        }
        res.send(city);
    })
        .catch((e)=>{
            console.log("Error",e);
        })
})

app.listen(5151);