const mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/reactexam");
var stateSchema=new mongoose.Schema({
    statename:{
        type:String
    }
})

var state1=mongoose.model('state1',stateSchema);
module.exports={state1}